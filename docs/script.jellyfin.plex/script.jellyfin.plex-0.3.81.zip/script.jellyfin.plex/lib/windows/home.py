"""Home window: library shortcuts plus Plex-style hub rows (Continue
Watching - a combined feed of in-progress Resume items and Next Up episodes -
plus Recently Added Movies / Recently Added TV / Recently Added Music).

self.result on close is one of:
  {"action": "browse", "library_id": ..., "library_name": ...}
  {"action": "open", "item_id": ..., "item_type": ..., "item_name": ...}
  {"action": "search"}
  {"action": "servers"}
  None (user backed out — lib/main.py treats this as "quit the addon")

The Playlists show/hide toggle next to Search doesn't close the window or
go through self.result at all - it flips an addon setting and repopulates
the Libraries row in place, the same "mutate immediately" pattern
lib/windows/detail.py uses for its watched/unwatched toggle.
"""

import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from lib.jellyfin import images, library
from lib.windows.kodigui import (
    BACK_ACTIONS,
    LOG_PREFIX,
    ControlledWindow,
    list_item,
    placeholder_art,
    progress_percent,
)

ADDON = xbmcaddon.Addon()


def _recently_added_item_limit():
    """The addon's "Recently Added item limit" setting - falls back to
    DEFAULT_RECENTLY_ADDED_ITEM_LIMIT if unset or not a valid int."""
    try:
        return int(ADDON.getSetting(RECENTLY_ADDED_ITEM_LIMIT_SETTING))
    except (TypeError, ValueError):
        return DEFAULT_RECENTLY_ADDED_ITEM_LIMIT


def _season_block_threshold():
    """The addon's "Group new episodes into a season block after" setting -
    falls back to library.SEASON_BLOCK_THRESHOLD if unset or not a valid
    int."""
    try:
        return int(ADDON.getSetting(SEASON_BLOCK_THRESHOLD_SETTING))
    except (TypeError, ValueError):
        return library.SEASON_BLOCK_THRESHOLD


HIDE_PLAYLISTS_SETTING = "hide_playlists"
SHOW_CONTINUE_WATCHING_SETTING = "show_continue_watching"
SHOW_RECENTLY_ADDED_MOVIES_SETTING = "show_recently_added_movies"
SHOW_RECENTLY_ADDED_TV_SETTING = "show_recently_added_tv"
SHOW_RECENTLY_ADDED_MUSIC_SETTING = "show_recently_added_music"
HIDE_WATCHED_RECENTLY_ADDED_MOVIES_SETTING = "hide_watched_recently_added_movies"
HIDE_WATCHED_RECENTLY_ADDED_TV_SETTING = "hide_watched_recently_added_tv"
HIDE_WATCHED_RECENTLY_ADDED_MUSIC_SETTING = "hide_watched_recently_added_music"
RECENTLY_ADDED_ITEM_LIMIT_SETTING = "recently_added_item_limit"
DEFAULT_RECENTLY_ADDED_ITEM_LIMIT = 10
SEASON_BLOCK_THRESHOLD_SETTING = "season_block_threshold"
SHOW_CLOCK_SETTING = "show_clock"
CLOCK_24_HOUR_SETTING = "clock_24_hour"

CTRL_LIBRARIES = 200
CTRL_CONTINUE_WATCHING = 201
CTRL_RECENTLY_ADDED_MOVIES = 203
CTRL_SEARCH = 204
CTRL_RECENTLY_ADDED_TV = 205
CTRL_SERVERS = 206
CTRL_RECENTLY_ADDED_MUSIC = 207
CTRL_PLAYLISTS_TOGGLE = 208
CTRL_SETTINGS = 209
CTRL_LOADING = 220

HUB_CONTROLS = (
    CTRL_CONTINUE_WATCHING, CTRL_RECENTLY_ADDED_MOVIES, CTRL_RECENTLY_ADDED_TV,
    CTRL_RECENTLY_ADDED_MUSIC,
)

# Libraries plus every hub row - one "step" each for the loading overlay's
# "N of TOTAL_LOAD_STEPS loaded" count, whether that step ultimately
# succeeds or (per _load_hub_row's own failure handling) fails and leaves
# its row empty; either way that step is done being attempted.
TOTAL_LOAD_STEPS = 1 + len(HUB_CONTROLS)


# Playlists is an auto-created Jellyfin library that isn't a real media
# collection to browse here (there's no browse.py support for it either) -
# hidden from the shortcut row by default rather than showing an empty/
# broken tile, but the toggle button next to Search lets it back in for
# anyone who does keep playlists there. The rest are shown in a fixed order
# (Movies, TV, Music) regardless of whatever order the server returns views
# in, with any other/unknown library type (including Playlists, when shown)
# kept after those, in the server's original relative order (Python's sort
# is stable) since there's nothing more specific to say about them.
LIBRARY_TYPE_ORDER = {"movies": 0, "tvshows": 1, "music": 2}


def _visible_library_views(views, hide_playlists=True):
    def is_hidden(view):
        return hide_playlists and view.get("CollectionType") == "playlists"

    visible = [v for v in views if not is_hidden(v)]
    return sorted(visible, key=lambda v: LIBRARY_TYPE_ORDER.get(v.get("CollectionType"), len(LIBRARY_TYPE_ORDER)))


def _library_list_item(client, view):
    li = xbmcgui.ListItem(label=view.get("Name", ""))
    art_url = images.primary_image_url(client, view) or placeholder_art(view)
    li.setArt({"thumb": art_url, "poster": art_url})
    li.setProperty("jellyfin_id", view.get("Id", ""))
    li.setProperty("collection_type", view.get("CollectionType") or "")
    return li


class HomeWindow(ControlledWindow):
    xmlFile = "script-jellyfin-home.xml"

    def setup(self, client=None, select_control_id=None, select_item_id=None, **kwargs):
        super().setup(**kwargs)
        self.client = client
        self.views = None
        self._load_settings()
        self.loaded_steps = 0
        # Which item (if any) to re-select once its row is loaded, e.g.
        # because Home is being shown again after the user backed out of
        # whatever they opened from here - lets Back land back on the same
        # tile instead of resetting focus to the Libraries row.
        self.select_control_id = select_control_id
        self.select_item_id = select_item_id
        self._selected_target = False
        # onInit() overwrites this right before _load() actually starts;
        # set here too so tests that call _load() directly (bypassing
        # onInit(), per this file's existing convention) don't hit an
        # AttributeError.
        self._load_started = time.time()

    def onInit(self):
        # The actual fetch runs on a background thread (see _load()) so a
        # slow/large library (e.g. a big Music collection - the request that
        # first exposed this) doesn't freeze the whole GUI thread for the
        # duration; each population step below checks closed_event first in
        # case the user has already backed out while it was in flight.
        self.setFocusId(CTRL_LIBRARIES)
        self._update_playlists_toggle_label()
        self._update_clock_properties()
        # Home is re-entered (onInit runs again) every time the user backs
        # out to it, so this is the natural point to drop the browse-level
        # cache - otherwise a show/season the server only just finished
        # scanning in can be invisible in a library listing already cached
        # from earlier this session until an unrelated watched-state change
        # happens to clear it (see clear_browse_cache()'s docstring).
        library.clear_browse_cache()
        self._load_started = time.time()
        self._update_loading_label()
        threading.Thread(target=self._load, daemon=True).start()
        threading.Thread(target=self._tick_progress, daemon=True).start()
        threading.Thread(target=self._tick_clock, daemon=True).start()

    def onAction(self, action):
        # Home is the root screen - backing out of it means quitting the
        # whole addon, so it asks for confirmation itself, unlike every
        # other window's plain Back. Showing the dialog here (before
        # deciding whether to close) rather than after Home has already
        # closed (the previous approach, in lib/main.py's _home_loop) means
        # it renders layered on top of Home's own screen instead of over
        # whatever's behind the addon - Kodi's own skin - which looked like
        # the addon had already quit before the user had even answered.
        if action.getId() in BACK_ACTIONS:
            self._confirm_quit()
            return
        super().onAction(action)

    def _confirm_quit(self):
        if xbmc.Monitor().abortRequested():
            # Kodi is already tearing down for shutdown - a confirmation
            # dialog here would sit forever waiting for a click that will
            # never come, missing Kodi's 5-second "stop the script" grace
            # period. Just let Back close Home like normal.
            self.result = None
            self.close()
            return
        confirmed = xbmcgui.Dialog().yesno("Jellyfin", "Quit and return to Kodi?")
        # Re-check after the dialog, not just before it: Kodi can force the
        # yesno() dialog closed mid-shutdown and hand back a falsy result
        # (as if the user picked "No") with abort now signalled - treating
        # that as "stay on Home" would keep this window's own doModal()
        # running right through Kodi's shutdown grace period instead of
        # exiting cleanly.
        if confirmed or xbmc.Monitor().abortRequested():
            self.result = None
            self.close()
        # else: declined and not aborting - swallow Back, stay on Home.

    def _update_loading_label(self):
        # Shows both: a simulated percentage that keeps visibly climbing
        # even during a long stretch with no step completing (the real case
        # this was built for: a hub-row fetch that can take minutes against
        # a slow real library), and the actual "N of TOTAL_LOAD_STEPS"
        # count, which stays honest during that same stretch - a fetch
        # that's still stuck on step 2 says so, no matter how confidently
        # the percentage is climbing.
        percent = progress_percent(self._load_started)
        self.getControl(CTRL_LOADING).setLabel(
            f"Loading library… {percent}% ({self.loaded_steps} of {TOTAL_LOAD_STEPS})"
        )

    def _tick_progress(self):
        # A separate ticker rather than updating the label only after each
        # step completes in _load()/_load_hub_row() - a single slow step can
        # otherwise mean no visible update for a long stretch. This ticks
        # independently of step completion.
        while True:
            xbmc.sleep(300)
            if self.closed_event.is_set() or self.loading_done.is_set():
                return
            self._update_loading_label()

    def _load(self):
        # Only the Libraries row is essential - without it there's no Home
        # screen at all, so a failure there still closes the window. Each
        # hub row below is independent: a slow/failing real library (seen in
        # practice: a large Music collection's "recently added" query) must
        # not take the other, already-succeeded rows down with it.
        try:
            views = self._timed("get_views", library.get_views, self.client)
        except Exception as exc:  # noqa: BLE001 - a server/network failure shouldn't crash the addon
            if self.closed_event.is_set():
                return
            xbmcgui.Dialog().notification("Jellyfin", f"Couldn't load Home: {exc}")
            self.result = None
            self.close()
            return
        if self.closed_event.is_set():
            return
        visible_views = _visible_library_views(views, self.hide_playlists)
        self._populate(CTRL_LIBRARIES, visible_views, is_library=True)
        self._maybe_restore_selection(CTRL_LIBRARIES, visible_views)
        # self.views must only become non-None after the populate above has
        # returned - _toggle_playlists_visibility() (GUI thread) uses it as
        # its "safe to repopulate CTRL_LIBRARIES" guard, and this control
        # must never be mutated from two threads at once.
        self.views = views
        self.loaded_steps += 1
        self._update_loading_label()

        self._load_hub_row(
            CTRL_CONTINUE_WATCHING, "get_continue_watching", self._get_continue_watching, self.client,
            populate=self._populate_episode_aware, enabled=self.show_continue_watching,
        )
        self._load_hub_row(
            CTRL_RECENTLY_ADDED_MOVIES, "latest movies", self._latest, views, "movies",
            enabled=self.show_recently_added_movies,
        )
        self._load_hub_row(
            CTRL_RECENTLY_ADDED_TV, "latest tvshows", self._latest_tv_episodes, views,
            populate=self._populate_tv_posters, enabled=self.show_recently_added_tv,
        )
        self._load_hub_row(
            CTRL_RECENTLY_ADDED_MUSIC, "latest music", self._latest, views, "music",
            enabled=self.show_recently_added_music,
        )
        self.loading_done.set()
        if not self.closed_event.is_set():
            self.getControl(CTRL_LOADING).setVisible(False)

    def _load_hub_row(self, control_id, label, fetch, *args, populate=None, enabled=True, **kwargs):
        if self.closed_event.is_set():
            return
        try:
            if not enabled:
                return
            try:
                items = self._timed(label, fetch, *args, **kwargs)
                if self.closed_event.is_set():
                    return
                (populate or self._populate)(control_id, items)
                self._maybe_restore_selection(control_id, items)
            except Exception as exc:  # noqa: BLE001 - one slow/broken row shouldn't blank the rest of Home
                xbmc.log(f"{LOG_PREFIX} Home: {label} failed, leaving that row empty: {exc}", xbmc.LOGWARNING)
                return
        finally:
            # Counts as a completed step (for the loading overlay's "N of
            # TOTAL_LOAD_STEPS" count) whether the fetch succeeded, failed,
            # or the window closed mid-fetch - either way there's nothing
            # left to wait on for this row.
            self.loaded_steps += 1
            if not self.closed_event.is_set():
                self._update_loading_label()

    def _maybe_restore_selection(self, control_id, items):
        if control_id != self.select_control_id or self._selected_target:
            return
        for index, item in enumerate(items):
            if item.get("Id") == self.select_item_id:
                self.getControl(control_id).selectItem(index)
                self.setFocusId(control_id)
                self._selected_target = True
                return

    def _timed(self, label, fn, *args, **kwargs):
        """Logs how long each Home fetch step took (or how long it ran
        before failing) - a slow real library (e.g. a big Music collection)
        can make any one of these steps the one that's actually slow, and
        without this a timeout only shows as an unexplained gap in the log."""
        started = time.time()
        try:
            return fn(*args, **kwargs)
        finally:
            xbmc.log(f"{LOG_PREFIX} Home: {label} took {time.time() - started:.1f}s", xbmc.LOGINFO)

    def _get_continue_watching(self, client):
        """Combined Continue Watching feed: in-progress items (Resume) first,
        then Next Up episodes not already covered by an in-progress item for
        the same show - a show already in Resume doesn't need a second tile
        just because its next episode also qualifies for Next Up."""
        resume_items = library.get_resume(client)
        next_up_items = library.get_next_up(client)
        seen_ids = {item["Id"] for item in resume_items}
        seen_series_ids = {item["SeriesId"] for item in resume_items if item.get("SeriesId")}
        merged = list(resume_items)
        for item in next_up_items:
            if item["Id"] in seen_ids or item.get("SeriesId") in seen_series_ids:
                continue
            merged.append(item)
        return merged

    def _latest(self, views, collection_type):
        latest = []
        for view in views:
            if view.get("CollectionType") != collection_type:
                continue
            latest.extend(library.get_latest(self.client, parent_id=view.get("Id"), limit=self.recently_added_item_limit))
        if collection_type == "movies" and self.hide_watched_recently_added_movies:
            latest = [item for item in latest if not library.is_played(item)]
        if collection_type == "music" and self.hide_watched_recently_added_music:
            latest = [item for item in latest if not library.is_played(item)]
        return latest

    def _latest_tv_episodes(self, views):
        """Recently added TV: individual episodes, newest-added first, except
        a season that got a whole batch of episodes added at once collapses
        into a single block tile (see library.get_latest_episodes). Watched
        episodes are dropped before that grouping happens (rather than
        filtered from the final list), so a block's episode tally only ever
        counts its still-unwatched episodes and a fully-watched batch is
        hidden entirely instead of showing an empty-looking block."""
        latest = []
        for view in views:
            if view.get("CollectionType") != "tvshows":
                continue
            latest.extend(library.get_latest_episodes(
                self.client, parent_id=view.get("Id"), limit=self.recently_added_item_limit,
                block_threshold=self.season_block_threshold,
                hide_watched=self.hide_watched_recently_added_tv,
            ))
        return latest

    def _populate(self, control_id, items, is_library=False):
        control = self.getControl(control_id)
        control.reset()
        list_items = []
        for item in items:
            if is_library:
                list_items.append(_library_list_item(self.client, item))
            else:
                primary = images.primary_image_url(self.client, item)
                backdrop = images.backdrop_image_url(self.client, item)
                list_items.append(list_item(item, primary, backdrop))
        control.addItems(list_items)

    def _populate_tv_posters(self, control_id, items):
        """Recently Added TV: each tile shows its show's poster rather than
        the episode's own landscape screengrab - images.primary_image_url()
        would use that screengrab when the episode has one (which most do),
        so this always goes straight to the series poster instead, the same
        art series_poster_url() uses for Next Up/Continue Watching."""
        control = self.getControl(control_id)
        control.reset()
        list_items = []
        for item in items:
            primary = images.series_poster_url(self.client, item)
            backdrop = images.backdrop_image_url(self.client, item)
            list_items.append(list_item(item, primary, backdrop))
        control.addItems(list_items)

    def _populate_episode_aware(self, control_id, items):
        """Continue Watching's populate step. Episode items show their show's
        poster (current season's own poster if it has one, else the series
        poster) instead of their own landscape screengrab, so the row reads
        as "here's what's next/in progress for each show" rather than a
        strip of random stills. Movies keep their own poster art since they
        have no season/series."""
        season_ids = {item["SeasonId"] for item in items if item.get("SeasonId")}
        seasons = library.get_items_by_ids(self.client, list(season_ids))
        season_by_id = {season["Id"]: season for season in seasons}

        control = self.getControl(control_id)
        control.reset()
        list_items = []
        for item in items:
            season_id = item.get("SeasonId")
            if season_id:
                primary = images.series_poster_url(self.client, item, season=season_by_id.get(season_id))
            else:
                primary = images.primary_image_url(self.client, item)
            backdrop = images.backdrop_image_url(self.client, item)
            list_items.append(list_item(item, primary, backdrop))
        control.addItems(list_items)

    def handle_click(self, control_id):
        if control_id == CTRL_LIBRARIES:
            self._open_library()
        elif control_id in HUB_CONTROLS:
            self._open_item(control_id)
        elif control_id == CTRL_SEARCH:
            self.result = {"action": "search"}
            self.close()
        elif control_id == CTRL_SERVERS:
            self.result = {"action": "servers"}
            self.close()
        elif control_id == CTRL_PLAYLISTS_TOGGLE:
            self._toggle_playlists_visibility()
        elif control_id == CTRL_SETTINGS:
            self._open_addon_settings()

    def _update_playlists_toggle_label(self):
        self.getControl(CTRL_PLAYLISTS_TOGGLE).setLabel("Show Playlists" if self.hide_playlists else "Hide Playlists")

    def _update_clock_properties(self):
        # Only the visibility toggle is a Window property set once here -
        # the ticking clock text itself is clock_text, updated once a
        # second by _tick_clock() on a background thread (started from
        # onInit, alongside _tick_progress).
        self.setProperty("show_clock", "true" if self.show_clock else "")
        self._update_clock_text()

    def _update_clock_text(self):
        # Kodi's System.Time infolabel format tokens don't actually control
        # 12- vs 24-hour (that follows the OS/Kodi regional locale setting
        # regardless of the format string given), so honoring clock_24_hour
        # means formatting the time in Python instead of relying on a skin
        # $INFO label. strftime's %-I (no leading zero) isn't supported on
        # Windows, hence the manual lstrip("0") instead.
        now = time.localtime()
        if self.clock_24_hour:
            text = time.strftime("%H:%M", now)
        else:
            text = time.strftime("%I:%M %p", now).lstrip("0")
        self.setProperty("clock_text", text)

    def _tick_clock(self):
        # Event.wait(timeout) rather than xbmc.sleep(1000): it returns
        # immediately once the window closes instead of waiting out the
        # full second, and (unlike xbmc.sleep, a no-op in the test stub)
        # it's a real wait even under pytest, so this doesn't spin the CPU
        # for as long as Home stays open in a test that calls onInit().
        while not self.closed_event.wait(timeout=1.0):
            self._update_clock_text()

    def _toggle_playlists_visibility(self):
        if self.views is None:
            return
        self.hide_playlists = not self.hide_playlists
        ADDON.setSetting(HIDE_PLAYLISTS_SETTING, "true" if self.hide_playlists else "false")
        self._update_playlists_toggle_label()
        self._populate(CTRL_LIBRARIES, _visible_library_views(self.views, self.hide_playlists), is_library=True)

    def _open_addon_settings(self):
        # openSettings() blocks (shows Kodi's native addon settings dialog)
        # until the user closes it, so this only resumes once whatever they
        # changed - hub row toggles, hide_playlists, sort order, etc. - is
        # already saved; refresh Home in place afterwards rather than
        # requiring a manual Back/re-open to see the effect.
        ADDON.openSettings()
        if self.closed_event.is_set():
            return
        self._refresh_after_settings_change()

    def _load_settings(self):
        self.hide_playlists = ADDON.getSetting(HIDE_PLAYLISTS_SETTING) != "false"
        # Per-row visibility toggles, addon settings > Home - each row is
        # simply never fetched/populated when off, so the group's own
        # Container(x).NumItems>0 visibility condition in the skin XML
        # keeps it collapsed without any XML changes needed here.
        self.show_continue_watching = ADDON.getSetting(SHOW_CONTINUE_WATCHING_SETTING) != "false"
        self.show_recently_added_movies = ADDON.getSetting(SHOW_RECENTLY_ADDED_MOVIES_SETTING) != "false"
        self.show_recently_added_tv = ADDON.getSetting(SHOW_RECENTLY_ADDED_TV_SETTING) != "false"
        self.show_recently_added_music = ADDON.getSetting(SHOW_RECENTLY_ADDED_MUSIC_SETTING) != "false"
        self.hide_watched_recently_added_movies = ADDON.getSetting(HIDE_WATCHED_RECENTLY_ADDED_MOVIES_SETTING) == "true"
        self.hide_watched_recently_added_tv = ADDON.getSetting(HIDE_WATCHED_RECENTLY_ADDED_TV_SETTING) == "true"
        self.hide_watched_recently_added_music = ADDON.getSetting(HIDE_WATCHED_RECENTLY_ADDED_MUSIC_SETTING) == "true"
        self.recently_added_item_limit = _recently_added_item_limit()
        self.season_block_threshold = _season_block_threshold()
        self.show_clock = ADDON.getSetting(SHOW_CLOCK_SETTING) != "false"
        self.clock_24_hour = ADDON.getSetting(CLOCK_24_HOUR_SETTING) != "false"

    def _refresh_after_settings_change(self):
        self._load_settings()
        self._update_playlists_toggle_label()
        self._update_clock_properties()
        # A settings-driven refresh re-fetches every row from scratch (the
        # simplest way to correctly pick up a newly-enabled row, which was
        # never fetched the first time around) - same background-thread
        # pattern onInit() uses so this doesn't freeze the GUI thread.
        self.loading_done.clear()
        self.loaded_steps = 0
        self._load_started = time.time()
        self._update_loading_label()
        self.getControl(CTRL_LOADING).setVisible(True)
        threading.Thread(target=self._load, daemon=True).start()
        threading.Thread(target=self._tick_progress, daemon=True).start()

    def _open_library(self):
        selected = self.getControl(CTRL_LIBRARIES).getSelectedItem()
        if not selected:
            return
        self.result = {
            "action": "browse",
            "library_id": selected.getProperty("jellyfin_id"),
            "library_name": selected.getLabel(),
            "collection_type": selected.getProperty("collection_type"),
            "control_id": CTRL_LIBRARIES,
            "item_id": selected.getProperty("jellyfin_id"),
        }
        self.close()

    def _open_item(self, control_id):
        selected = self.getControl(control_id).getSelectedItem()
        if not selected:
            return
        self.result = {
            "action": "open",
            "item_id": selected.getProperty("jellyfin_id"),
            "item_type": selected.getProperty("jellyfin_type"),
            "item_name": selected.getLabel(),
            "item_overview": selected.getProperty("overview"),
            "control_id": control_id,
        }
        self.close()
