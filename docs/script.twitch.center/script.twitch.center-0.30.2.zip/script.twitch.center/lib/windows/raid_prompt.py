"""Non-modal confirm dialog shown when the watched channel raids out to another one -
offers to switch playback there, auto-accepting after a countdown unless declined.

Must stay non-modal (show()/close()), never doModal(): doModal() is invoked from
ChatOverlay's background pump thread here, not the addon's single main/invoker thread
(which already runs its own persistent doModal() loop for MainWindow for the addon's whole
lifetime). Kodi's modal-dialog wait loop isn't safe to enter from a second thread - closing
it from a third thread (this dialog's own countdown timer) doesn't properly unwind Kodi's
internal modal-dialog counter, leaving it stuck permanently: confirmed live via kodi.log
("Activate of window '10000' refused because there are active modal dialogs", still true
27+ minutes after the dialog should have closed, blocking every remote button that tried to
activate a new window). show()/close() is the same non-modal pattern ChatOverlay itself
already uses safely from background threads elsewhere in this codebase."""
import threading
import time

import xbmc
import xbmcgui

_DEFAULT_COUNTDOWN_SECONDS = 15


class RaidPromptDialog(xbmcgui.WindowXMLDialog):
    DECLINE_BUTTON_ID = 201
    COUNTDOWN_LABEL_ID = 202

    _DECLINE_ACTIONS = (
        xbmcgui.ACTION_PREVIOUS_MENU,
        xbmcgui.ACTION_NAV_BACK,
    )

    def __init__(self, *args, countdown_seconds=_DEFAULT_COUNTDOWN_SECONDS, sleep_fn=None,
                 **kwargs):
        super().__init__(*args, **kwargs)
        self._countdown_seconds = countdown_seconds
        self._sleep_fn = sleep_fn or time.sleep
        self._display_name = ""
        self._to_channel = ""
        self._viewer_count = 0
        self._on_result = None
        self._thread = None
        self._finish_lock = threading.Lock()
        self._finished = False

    def prompt(self, display_name, to_channel, viewer_count, on_result):
        self._display_name = display_name
        self._to_channel = to_channel
        self._viewer_count = viewer_count
        self._on_result = on_result
        self._finished = False
        # Diagnostic trace for the "raid prompt closed near-instantly, no exception
        # anywhere" failure seen live 2026-09-06 - onInit's own try/except never fired,
        # so something outside onInit is behind it. Pin down exactly which stage runs
        # last next time this happens.
        xbmc.log("script.twitch.center: raid prompt prompt() calling show()", xbmc.LOGINFO)
        self.show()
        xbmc.log("script.twitch.center: raid prompt prompt() show() returned", xbmc.LOGINFO)

    def onDeinit(self):
        xbmc.log(
            "script.twitch.center: raid prompt onDeinit (finished=%r)" % (self._finished,),
            xbmc.LOGINFO,
        )

    def onInit(self):
        xbmc.log("script.twitch.center: raid prompt onInit entered", xbmc.LOGINFO)
        # Kodi's GUI-callback invoker can swallow an exception here without ever
        # reaching kodi.log when debug logging is off, leaving the dialog stuck
        # exactly like the countdown-thread failure documented above but with no
        # trace at all - log explicitly so this failure mode is never invisible again.
        try:
            # The dialog itself is easy to miss over live video (it's not modal and has
            # no attention-grabbing animation) - Kodi's built-in notification sound gives
            # an audible cue even when nobody's looking at the screen.
            xbmcgui.Dialog().notification(
                "Raid incoming",
                "%s is raiding to %s" % (self._display_name, self._to_channel),
            )
            self._update_label(self._countdown_seconds)
            self._thread = threading.Thread(target=self._countdown, daemon=True)
            self._thread.start()
        except Exception as exc:
            xbmc.log(
                "script.twitch.center: raid prompt onInit failed: " + repr(exc),
                xbmc.LOGERROR,
            )
            self._finish(True)

    def _countdown(self):
        # An uncaught exception here otherwise kills this thread silently - Python's default
        # thread excepthook writes to stderr, which Kodi's log doesn't capture, so the dialog
        # just freezes forever on whatever was last shown with zero trace in kodi.log
        # (confirmed live: raid prompt loaded, then total silence until the stream itself hit
        # eof over a minute later - no auto-switch attempt, no error, nothing). Fail visibly,
        # and fail safe by still finishing as accepted rather than leaving the dialog stuck.
        try:
            remaining = self._countdown_seconds
            while remaining > 0:
                self._sleep_fn(1)
                remaining -= 1
                self._update_label(remaining)
        except Exception as exc:
            xbmc.log(
                "script.twitch.center: raid prompt countdown failed: " + repr(exc),
                xbmc.LOGERROR,
            )
        self._finish(True)

    def _update_label(self, remaining):
        control = self._safe_control(self.COUNTDOWN_LABEL_ID)
        if control is None:
            return
        control.setLabel(
            "%s is raiding to %s (%d viewers) - switching in %ds" % (
                self._display_name, self._to_channel, self._viewer_count, remaining
            )
        )

    def _safe_control(self, control_id):
        try:
            return self.getControl(control_id)
        except Exception:
            return None

    def _finish(self, accepted):
        with self._finish_lock:
            if self._finished:
                return
            self._finished = True
        self.close()
        on_result = self._on_result
        if on_result is not None:
            on_result(accepted)

    def onClick(self, control_id):
        if control_id == self.DECLINE_BUTTON_ID:
            self._finish(False)

    def onAction(self, action):
        if action.getId() in self._DECLINE_ACTIONS:
            self._finish(False)
            return
        super().onAction(action)
